Assignment 3
Vivian Martinez

Calculator

This application supports Addition, Subtraction, Multiplication, Division, Negation, Square Root, and Decimals.

I struggled with solving square root and negation and referred to a bunch of youtube tutorials and online forums.
I eventually learned about using a dynamic object and using the programming language javascript to give me my desired result.

https://www.youtube.com/watch?v=VaJLCxnCwO8&feature=youtu.be